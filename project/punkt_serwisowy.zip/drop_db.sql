SET client_encoding='utf-8';

DROP VIEW naprawa_koszt;
DROP TABLE czesc_zamienna;
DROP TABLE naprawa;
DROP TABLE specjalizacja;
DROP TABLE pracownik;
DROP TABLE usterka;
DROP TABLE rodzaj_usterki;
DROP TABLE telefon;
DROP TABLE model;
DROP TABLE klient;
DROP TABLE naprawa_arch;
